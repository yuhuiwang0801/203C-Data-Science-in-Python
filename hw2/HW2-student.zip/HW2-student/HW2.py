# HW2
# Name:
# Collaborators:
# Date:

import random

def count_characters(s):
    """WRITE DOCSTRING HERE
    """
    pass # replace with your code


def count_ngrams(s, n):
    """WRITE DOCSTRING HERE
    """
    pass # replace with your code


def markov_text(s, n, length, seed):
    """WRITE DOCSTRING HERE
    """
    pass # replace with your code
